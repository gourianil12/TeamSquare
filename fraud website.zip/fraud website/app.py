from flask import Flask, request, jsonify, render_template
import joblib
import numpy as np

app = Flask(__name__)

# Load model and scaler
model = joblib.load('fraud_model.pkl')
scaler = joblib.load('scaler.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    input_features = np.array([[ 
        data['Order_Value'], 
        data['Customer_Age'], 
        data['Previous_Failed_Deliveries'],
        data['Address_Valid'],
        data['Order_Hour'],
        data['Same_Day_Delivery_Requested'],
        data['Payment_Method_Code']
    ]])
    scaled = scaler.transform(input_features)
    prediction = model.predict(scaled)[0]

    # Human-readable explanation
    reasons = []
    if prediction == 1:
        if data['Order_Value'] > 5000:
            reasons.append("high order value")
        if data['Address_Valid'] == 0:
            reasons.append("invalid delivery address")
        if data['Previous_Failed_Deliveries'] > 2:
            reasons.append("multiple failed deliveries")
        if data['Same_Day_Delivery_Requested'] == 1:
            reasons.append("urgent same-day delivery request")

        explanation = " This order is flagged as fraudulent due to " + ", ".join(reasons) + "."
    else:
        if data['Address_Valid'] == 1:
            reasons.append("valid address")
        if data['Previous_Failed_Deliveries'] == 0:
            reasons.append("no failed deliveries")
        if 8 <= data['Order_Hour'] <= 20:
            reasons.append("normal ordering time")
        if data['Order_Value'] < 1000:
            reasons.append("reasonable order value")

        explanation = " This order appears genuine because of " + ", ".join(reasons) + "."

    return jsonify({
        'prediction': int(prediction),
        'explanation': explanation
    })

if __name__ == '__main__':
    app.run(debug=True)
